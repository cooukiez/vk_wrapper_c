#include <stdio.h>
#include <string.h>

#include "GLFW/glfw3.h"
#include "vulkan/vulkan.h"

#define GLFW_INCLUDE_VULKAN

const VkComponentMapping DEFAULT_COMPONENT_MAPPING = {
    .r = VK_COMPONENT_SWIZZLE_IDENTITY,
    .g = VK_COMPONENT_SWIZZLE_IDENTITY,
    .b = VK_COMPONENT_SWIZZLE_IDENTITY,
    .a = VK_COMPONENT_SWIZZLE_IDENTITY};

const VkImageSubresourceRange DEFAULT_SUBRESOURCE_RANGE = {
    .aspectMask = VK_IMAGE_ASPECT_COLOR_BIT,
    .baseMipLevel = 0,
    .levelCount = 1,
    .baseArrayLayer = 0,
    .layerCount = 1};

struct PhyDevGroup {
  VkPhysicalDevice *dev;
  VkPhysicalDeviceProperties prop;
  VkPhysicalDeviceMemoryProperties mem_prop;
  VkDeviceSize mem_total;
};

struct DevGroup {
  VkDevice dev;
  uint32_t qf_best_idx;
  VkQueue q_graph, q_pres;
  char single_queue;
};

struct SurfaceGroup {
  GLFWwindow *window;
  VkSurfaceKHR surf;
  VkBool32 supported;
  VkSurfaceFormatKHR form; // TODO: support multiple formats
  char mailbox_mode_supported;

  // NEED UPDATING ON RESIZE
  VkSurfaceCapabilitiesKHR caps;
  char extent_suitable;
  VkExtent2D actual_extent;
};

struct SwapchainGroup {
  VkSwapchainKHR swap;
  uint32_t img_count;
  VkImage *imgs;
  VkImageView *img_views;
};

#ifndef VK_CORE_H
#define VK_CORE_H

#endif