#include <cglm/cglm.h>

#include "buffer.h"

struct Vertex {
    vec2 pos;
    vec3 color;
};

struct UniformSet {
    mat4 model;
    mat4 view;
    mat4 proj;
};

#ifndef RENDER_H
#define RENDER_H

#endif